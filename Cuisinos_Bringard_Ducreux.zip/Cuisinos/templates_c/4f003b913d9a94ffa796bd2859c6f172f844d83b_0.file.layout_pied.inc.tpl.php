<?php
/* Smarty version 3.1.30, created on 2018-01-07 14:48:20
  from "C:\wamp64\www\siteCuisine\trunk\Cuisinos\application\views\layout\layout_pied.inc.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a52333405d4c7_65982069',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4f003b913d9a94ffa796bd2859c6f172f844d83b' => 
    array (
      0 => 'C:\\wamp64\\www\\siteCuisine\\trunk\\Cuisinos\\application\\views\\layout\\layout_pied.inc.tpl',
      1 => 1513269940,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a52333405d4c7_65982069 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="row">
	<nav class="pFooter col-sm-12 navbar-light bg-light">
		<p>&copy; IUT de Provence, site Arles 2017</p>
	</nav>
</div><?php }
}
